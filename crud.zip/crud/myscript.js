//------- add student-----------

function addStudent() {
  var x = document.getElementById("myDiv");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
// ---------submit form-----------
var selectedRow = null;
var result = [];



function onFormSubmit() {

  var formData = readFormData();

  if (selectedRow == null)
    insertNewRecord(formData);
  else
    updateRecord(formData);
  resetForm();
}

function readFormData() {
  var formData = {};
  formData["id"] = document.getElementById("id").value;
  formData["firstname"] = document.getElementById("firstname").value;
  formData["fname"] = document.getElementById("fname").value;
  formData["dob"] = document.getElementById("dob").value;
  formData["address"] = document.getElementById("address").value;
  return formData;
}

// ------------create data--------------
function insertNewRecord(data) {
  var table = document.getElementById("studentList").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.length);
  cell1 = newRow.insertCell(0);
  cell1.innerHTML = data.id;
  cell2 = newRow.insertCell(1);
  cell2.innerHTML = data.firstname;
  cell3 = newRow.insertCell(2);
  cell3.innerHTML = data.fname;
  cell4 = newRow.insertCell(3);
  cell4.innerHTML = data.dob;
  cell5 = newRow.insertCell(4);
  cell5.innerHTML = data.address;
  cell6 = newRow.insertCell(5);
  cell6.innerHTML = ` <button class="editbtn" onClick="onEdit(this)">Edit</button>
                    <button class="deletebtn" onClick="onDelete(this)">Delete</button>`

  // if(localStorage.getItem('result') == null){
  //   // result = [];
  // } else {
  //   result = JSON.parse(localStorage.getItem('result'));
  // }

  var studentRecord = { id : data.id , firstname :data.firstname ,fname :data.fname , dob:data.dob, address :data.address };
  result.push(studentRecord);

  localStorage.setItem('result' , JSON.stringify(result))
  // console.log(result);
}

//---------localStorage getItem -----------

window.addEventListener("DOMContentLoaded" ,(res) =>{
  if (localStorage.getItem('result')) {
    var result =JSON.parse(localStorage.getItem('result'))
    console.log(result);
    result.map((res) =>  {
      insertNewRecord(res);
      return res + 1 ;
    });
  }
  // console.log("Dom")
});

//--------resetForm-----------
function resetForm() {
  document.getElementById("id").value = "";
  document.getElementById("firstname").value = "";
  document.getElementById("fname").value = "";
  document.getElementById("dob").value = "";
  document.getElementById("address").value = "";
  selectedRow = null;
}
// ------------ Edit table-----------

function onEdit(td) {
  selectedRow = td.parentElement.parentElement;
  document.getElementById("id").value = selectedRow.cells[0].innerHTML;
  document.getElementById("firstname").value = selectedRow.cells[1].innerHTML;
  document.getElementById("fname").value = selectedRow.cells[2].innerHTML;
  document.getElementById("dob").value = selectedRow.cells[3].innerHTML;
  document.getElementById("address").value = selectedRow.cells[4].innerHTML;
}

// let onEdit = (td) => {
//   let selectedRow = td.parentElement.parentElement;

//   document.getElementById("firstname").value = selectedRow.cells[0].innerHTML;
//   document.getElementById("fname").value = selectedRow.cells[1].innerHTML;
//   document.getElementById("dob").value = selectedRow.cells[2].innerHTML;
//   document.getElementById("address").value = selectedRow.cells[3].innerHTML;
//   updateRecord(result);
// };

// ------------Update table------------

function updateRecord(formData) {
  debugger;
  selectedRow.cells[0].innerHTML = formData.id;
  selectedRow.cells[1].innerHTML = formData.firstname;
  selectedRow.cells[2].innerHTML = formData.fname;
  selectedRow.cells[3].innerHTML = formData.dob;
  selectedRow.cells[4].innerHTML = formData.address;
  var studentRecord = { id : formData.id ,firstname :formData.firstname ,fname :formData.fname , dob:formData.dob, address :formData.address };
  result.push(studentRecord);

  // for (var i = 0; i < result.length; i++) {
  //   result[i].addEventListener('click', function(i) {
  //       console.log('You clicked element #' + i);
  //    }.bind(null, i));
  // }
localStorage.setItem('result', JSON.stringify(result));
  return (result);
  // console.log("result", result);


}

//----------- Delete table---------------

// function onDelete(td) {
//   if (confirm('Are you sure to delete this record ?')) {

//     row = td.parentElement.parentElement.remove();
//     document.getElementById('studentList').delete(row,rowIndex);
//     resetForm();
// }
// }


function onDelete(td) {
  debugger
  if (confirm('Are you sure to delete this record ?')) {
    row = td.parentElement.parentElement.remove();

    result.splice(td.parentElement.parentElement.id, 1);
    localStorage.setItem("result", JSON.stringify(result));
  
    console.log(result);
    // resetForm();
  };
}

// let onDelete = (e) => {
//   e.parentElement.parentElement.remove();

//   result.splice(e.parentElement.parentElement.id, 1);

//   localStorage.setItem("result", JSON.stringify(result));

//   console.log(result);
// };


// -------------searching-------------

function myFunction() {
  var input, filter, table, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("studentList");
  var tbodytr = table.tBodies[0].rows
  // tr = table.getElementsByTagName("tr");
  // td = table.getElementsByTagName("td");
  for (var i = 0; i < tbodytr.length; i++) {
    var tds = tbodytr[i].getElementsByTagName("td");
    var flag = false;
    for (var j = 0; j < tds.length; j++) {
      var td = tds[j];
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        flag = true;
      }
    }
    if (flag) {
      tbodytr[i].style.display = "table-row";
    }
    else {
      tbodytr[i].style.display = "none";
    }
  }
}

// --------------sorting----------------

function sortTableByColumn(table, column, asc = true) {
  debugger
  const dirModifier = asc ? 1 : -1;
  const tBody = table.tBodies[0];
  const rows = Array.from(tBody.querySelectorAll("tr"));

  // Sort each row
  const sortedRows = rows.sort((a, b) => {
      const aColText = a.querySelector(`td:nth-child(${ column + 1 })`).textContent.trim();
      const bColText = b.querySelector(`td:nth-child(${ column + 1 })`).textContent.trim();

      return aColText > bColText ? (1 * dirModifier) : (-1 * dirModifier);
  });

  // // Remove all existing TRs from the table
  // while (tBody.firstChild) {
  //     tBody.removeChild(tBody.firstChild);
  // }

  // Re-add the newly sorted rows
  tBody.append(...sortedRows);

  // Remember how the column is currently sorted
  table.querySelectorAll("th").forEach(th => th.classList.remove("th-sort-asc", "th-sort-desc"));
  table.querySelector(`th:nth-child(${ column + 1})`).classList.toggle("th-sort-asc", asc);
  table.querySelector(`th:nth-child(${ column + 1})`).classList.toggle("th-sort-desc", !asc);
}

document.querySelectorAll(".tableSort th").forEach(headerCell => {
  headerCell.addEventListener("click", () => {
      const tableElement = headerCell.parentElement.parentElement.parentElement;
      const headerIndex = Array.prototype.indexOf.call(headerCell.parentElement.children, headerCell);
      const currentIsAscending = headerCell.classList.contains("th-sort-asc");

      sortTableByColumn(tableElement, headerIndex, !currentIsAscending);
  });
});


// -----------------------pagination----------------------
var Pagination = {

  code: '',

  // --------------------
  // Utility
  // --------------------

  // converting initialize data
  Extend: function(data) {
      data = data || {};
      Pagination.size = data.size || 100;
      Pagination.page = data.page || 1;
      Pagination.step = data.step || 3;
  },

  // add pages by number (from [s] to [f])
  Add: function(s, f) {
      for (var i = s; i < f; i++) {
          Pagination.code += '<a>' + i + '</a>';
      }
  },

  // add last page with separator
  Last: function() {
      Pagination.code += '<i>...</i><a>' + Pagination.size + '</a>';
  },

  // add first page with separator
  First: function() {
      Pagination.code += '<a>1</a><i>...</i>';
  },

  // --------------------
  // Handlers
  // --------------------

  // change page
  Click: function() {
      Pagination.page = +this.innerHTML;
      Pagination.Start();
  },

  // previous page
  Prev: function() {
      Pagination.page--;
      if (Pagination.page < 1) {
          Pagination.page = 1;
      }
      Pagination.Start();
  },

  // next page
  Next: function() {
      Pagination.page++;
      if (Pagination.page > Pagination.size) {
          Pagination.page = Pagination.size;
      }
      Pagination.Start();
  },

  // --------------------
  // Script
  // --------------------

  // binding pages
  Bind: function() {
      var a = Pagination.e.getElementsByTagName('a');
      for (var i = 0; i < a.length; i++) {
          if (+a[i].innerHTML === Pagination.page) a[i].className = 'current';
          a[i].addEventListener('click', Pagination.Click, false);
      }
  },

  // write pagination
  Finish: function() {
      Pagination.e.innerHTML = Pagination.code;
      Pagination.code = '';
      Pagination.Bind();
  },

  // find pagination type
  Start: function() {
      if (Pagination.size < Pagination.step * 3 + 6) {
          Pagination.Add(1, Pagination.size + 1);
      }
      else if (Pagination.page < Pagination.step * 2 + 1) {
          Pagination.Add(1, Pagination.step * 2 + 4);
          Pagination.Last();
      }
      else if (Pagination.page > Pagination.size - Pagination.step * 2) {
          Pagination.First();
          Pagination.Add(Pagination.size - Pagination.step * 2 - 2, Pagination.size + 1);
      }
      else {
          Pagination.First();
          Pagination.Add(Pagination.page - Pagination.step, Pagination.page + Pagination.step + 1);
          Pagination.Last();
      }
      Pagination.Finish();
  },



  // --------------------
  // Initialization
  // --------------------

  // binding buttons
  Buttons: function(e) {
      var nav = e.getElementsByTagName('a');
      nav[0].addEventListener('click', Pagination.Prev, false);
      nav[1].addEventListener('click', Pagination.Next, false);
  },

  // create skeleton
  Create: function(e) {

      var html = [
          '<a>&#9668;</a>', // previous button
          '<span></span>',  // pagination container
          '<a>&#9658;</a>'  // next button
      ];

      e.innerHTML = html.join('');
      Pagination.e = e.getElementsByTagName('span')[0];
      Pagination.Buttons(e);
  },

  // init
  Init: function(e, data) {
      Pagination.Extend(data);
      Pagination.Create(e);
      Pagination.Start();
  }
};

/* * * * * * * * * * * * * * * * *
* Initialization                 *
* * * * * * * * * * * * * * * * */

var init = function() {
  Pagination.Init(document.getElementById('pagination'), {
      size: 10, // pages size
      page: 1,  // selected page
      step: 3   // pages before and after current
  });
};

document.addEventListener('DOMContentLoaded', init, false);


// ---------------------------------------------------------------------------------------------------------
  // var students = [];

  // function init() {
  //   if(localStorage.studentRecord){
  //     result = JSON.parse(localStorage.studentRecord);
  //     for(i=0;i<students.length;i++); {
  //       // insertNewRecord(students.firstname,students.fname,students.dob,students.address)
  //     }
  //   }
  // }
  
  //   var studentRecord = [{ firstname: data.firstname, fname: data.fname, dob: data.dob, address: data.address }];
  //   result.push(studentRecord);
    
  //   localStorage.setItem('result', JSON.stringify(result))
  //   console.log(result); 
  //   init();         

  // ----------------------------------------------------------------------------------------------------------------------

  //check for Navigation Timing API support
// function localGetData() {
// if (window.performance) {
//   console.info("window.performance works fine on this browser");
//   if(localStorage.getItem('result') == null){
//     // result = [];
//   } else {
//     result = JSON.parse(localStorage.getItem('result'));

//     var table = document.getElementById("studentList").getElementsByTagName('tbody')[0];
//   var table = localStorage.getItem(result)
//   var newRow = table.insertRow(table.length);
//   for (let i = 1; i < result.length; i++) {
//     const table = result[i];
//   }
//   }
// }
// cell1 = newRow.insertCell(0);
//   cell1.innerHTML = data.firstname;
//   cell2 = newRow.insertCell(1);
//   cell2.innerHTML = data.fname;
//   cell3 = newRow.insertCell(2);
//   cell3.innerHTML = data.dob;
//   cell4 = newRow.insertCell(3);
//   cell4.innerHTML = data.address;
//   cell5 = newRow.insertCell(4);
//   cell5.innerHTML = ` <button class="editbtn" onClick="onEdit(this)">Edit</button>
//                     <button class="deletebtn" onClick="onDelete(this)">Delete</button>`
// // console.info(performance.navigation.type);
// // if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
// //   console.info( "This page is reloaded" );
// // } else {
// //   console.info( "This page is not reloaded");
// // }
//  }




// check for Navigation Timing API support
// if (window.performance) {
//   console.info("window.performance works fine on this browser");
// }
// console.info(performance.navigation.type);
// if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
//   console.info("This page is reloaded");
// } else {
//   console.info("This page is not reloaded");
// }

// if (localStorage.getItem('result') == null) {
//   result = [];
// } else {
//   result = JSON.parse(localStorage.getItem('result'));
//   var table = document.getElementById("studentList").getElementsByTagName('tbody')[0];
//   var table = localStorage.getItem(result)
//   // var newRow = table.insertRow(table.length);
//   for (let i = 1; i < result.length; i++) {
//     const table = result[i];
//   }
//   cell1 = newRow.insertCell(0);
//   cell1.innerHTML = table.firstname;
//   cell2 = newRow.insertCell(1);
//   cell2.innerHTML = table.fname;
//   cell3 = newRow.insertCell(2);
//   cell3.innerHTML = table.dob;
//   cell4 = newRow.insertCell(3);
//   cell4.innerHTML = table.address;
//   cell5 = newRow.insertCell(4);
//   cell5.innerHTML = `<button class="editbtn" onClick="onEdit(this)">Edit</button>
//                        <button class="deletebtn" onClick="onDelete(this)">Delete</button>`
// }
// var studentRecord = [{ firstname: table.firstname, fname: table.fname, dob: table.dob, address: table.address }];
// result.push(studentRecord);

// localStorage.setItem('result', JSON.stringify(result))
